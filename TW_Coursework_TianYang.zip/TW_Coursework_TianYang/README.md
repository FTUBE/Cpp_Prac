'make clean' to clean the linker files:
'make' to build.
'./main [FILENAME]' to run the executable file.

p.s. Store the exempted keywords by categories in /dictionary.